package br.com.fiap.main;

import br.com.fiap.beans.Produto;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class TesteListaProduto {

    // String
    static String texto(String j){
        return JOptionPane.showInputDialog(j);
    }

    // int
    static int inteiro(String j){
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    // real
    static double real(String j){
        return Double.parseDouble(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) {

        // Preparar a Lista

        List<Produto> listaProduto = new ArrayList<Produto>();

        // Prepara objeto
        Produto objProduto = null;

        // Laço de repetição ( instancia objeto )
        do {
            objProduto = new Produto();
            objProduto.setMarca(texto("Marca"));
            objProduto.setTipo(texto("Tipo"));
            objProduto.setQuantidade(inteiro("Quantidade"));
            objProduto.setValor(real("Valor"));

            listaProduto.add(objProduto);

        } while (
                JOptionPane.showConfirmDialog(null,
                        "Adicionar mais produto no carrinho",
                        "CARRINHO DE COMPRAS",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE) == 0
        );

        //  com arrayList utilizamos foreach para a saida
        for (Produto p : listaProduto){
            System.out.println(
                    "\n\nMarca: " +p.getMarca() +
                    "\nTipo: " + p.getTipo() +
                    "\nQuantidade: " + p.getQuantidade() +
                    "\nValor: " + p.getValor()
            );
        }

    }

}
