package br.com.fiap.main;

import javax.swing.*;

public class Teste {

    // String
    static String texto(String j){
        return JOptionPane.showInputDialog(j);
    }

    // int
    static int numero(String j){
        return Integer.parseInt(JOptionPane.showInputDialog(j));
    }

    // real
    static double real(String j){
        return Double.parseDouble(JOptionPane.showInputDialog(j));
    }

    public static void main(String[] args) {

        

    }

}
