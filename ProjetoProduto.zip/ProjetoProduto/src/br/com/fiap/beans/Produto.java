package br.com.fiap.beans;

public class Produto {

    // visibilidade, tipo de dados e atributo
    private String marca;
    private String tipo;
    private int quantidade;
    private double valor;

    // Construtor vazio
    public Produto() {
        super();
    }

    // Construtor cheio
    public Produto(String marca, String tipo, int quantidade, double valor) {
        this.marca = marca;
        this.tipo = tipo;
        this.quantidade = quantidade;
        this.valor = valor;
    }

    // Getters (exibir\retornar)
    public String getMarca() {
        return marca;
    }

    public String getTipo() {
        return tipo;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public double getValor() {
        return valor;
    }

    // Setters (entradas)
    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    @Override
    public String toString() {
        return "Produto{" +
                "\nmarca='" + marca + '\'' +
                "\ntipo='" + tipo + '\'' +
                "\nquantidade=" + quantidade +
                "\nvalor=" + valor +
                '}';
    }
}
